<?php
/**
 *
 * This file is part of the phpBB Forum Software package.
 *
 * @copyright (c) phpBB Limited <https://www.phpbb.com>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 * For full copyright and license information, please see
 * the docs/CREDITS.txt file.
 *
 */

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'CK_VE_EXIF_CAPTION'				=> 'Données-EXIF',
	'CK_VE_EXIF_APERTURE'			=> 'Ouverture',
	'CK_VE_EXIF_CAM_MODEL'			=> 'Modèle',
	'CK_VE_EXIF_CAM_MAKE'			=> 'Marque',
	'CK_VE_EXIF_DATE'				=> 'Image prise le',

	'CK_VE_EXIF_EXPOSURE'			=> 'Vitesse',
	'CK_VE_EXIF_EXPOSURE_EXP'		=> '%s Sec',// 'CK_VE_EXIF_EXPOSURE' unit
	'CK_VE_EXIF_EXPOSURE_BIAS'		=> 'Compensation exposition',
	'CK_VE_EXIF_EXPOSURE_BIAS_EXP'	=> '%s EV',// 'CK_VE_EXIF_EXPOSURE_BIAS' unit
	'CK_VE_EXIF_EXPOSURE_PROG'		=> 'Mode exposition',
	'CK_VE_EXIF_EXPOSURE_PROG_0'	=> 'Non défini',
	'CK_VE_EXIF_EXPOSURE_PROG_1'	=> 'Manuel',
	'CK_VE_EXIF_EXPOSURE_PROG_2'	=> 'Normal',
	'CK_VE_EXIF_EXPOSURE_PROG_3'	=> 'Priorité ouverture',
	'CK_VE_EXIF_EXPOSURE_PROG_4'	=> 'Priorité vitesse',
	'CK_VE_EXIF_EXPOSURE_PROG_5'	=> 'Créatif (profondeur de champ élevée)',
	'CK_VE_EXIF_EXPOSURE_PROG_6'	=> 'Action (vitesse élevée)',
	'CK_VE_EXIF_EXPOSURE_PROG_7'	=> 'Portrait(arrière plan flou)',
	'CK_VE_EXIF_EXPOSURE_PROG_8'	=> 'Paysage (arrière plan net)',

	'CK_VE_EXIF_FLASH'				=> 'Flash',

	'CK_VE_EXIF_FLASH_CASE_0'		=> 'Flash non déclenché',
	'CK_VE_EXIF_FLASH_CASE_1'		=> 'Flash déclenché',
	'CK_VE_EXIF_FLASH_CASE_5'		=> 'lumière de retour non détectée',
	'CK_VE_EXIF_FLASH_CASE_7'		=> 'lumière de retour détectée',
	'CK_VE_EXIF_FLASH_CASE_8'		=> 'Allumé, Flash non déclenché',
	'CK_VE_EXIF_FLASH_CASE_9'		=> 'Flash déclenché, mode forcé',
	'CK_VE_EXIF_FLASH_CASE_13'		=> 'Flash déclenché, mode forcé, lumière de retour non détectée',
	'CK_VE_EXIF_FLASH_CASE_15'		=> 'Flash déclenché, mode forcé, lumière de retour détectée',
	'CK_VE_EXIF_FLASH_CASE_16'		=> 'Flash non déclenché, mode forcé',
	'CK_VE_EXIF_FLASH_CASE_20'		=> 'Eteint, Flash non déclenché, lumière de retour non détectée',
	'CK_VE_EXIF_FLASH_CASE_24'		=> 'Flash non déclenché, mode automatique',
	'CK_VE_EXIF_FLASH_CASE_25'		=> 'Flash déclenché, mode automatique',
	'CK_VE_EXIF_FLASH_CASE_29'		=> 'Flash déclenché, mode automatique, lumière de retour non détectée',
	'CK_VE_EXIF_FLASH_CASE_31'		=> 'Flash déclenché, mode automatique, lumière de retour détectée',
	'CK_VE_EXIF_FLASH_CASE_32'		=> 'Aucune fonction flash',
	'CK_VE_EXIF_FLASH_CASE_48'		=> 'Eteint, aucune fonction flash',
	'CK_VE_EXIF_FLASH_CASE_65'		=> 'Flash déclenché, mode réduction yeux rouges',
	'CK_VE_EXIF_FLASH_CASE_69'		=> 'Flash déclenché, mode réduction yeux rouges, lumière de retour non détectée',
	'CK_VE_EXIF_FLASH_CASE_71'		=> 'Flash déclenché, mode réduction yeux rouges, lumière de retour détectée',
	'CK_VE_EXIF_FLASH_CASE_73'		=> 'Flash déclenché, mode forcé, mode réduction yeux rouges',
	'CK_VE_EXIF_FLASH_CASE_77'		=> 'Flash déclenché, mode forcé, mode réduction yeux rouges, lumière de retour non détectée',
	'CK_VE_EXIF_FLASH_CASE_79'		=> 'Flash déclenché, mode forcé, mode réduction yeux rouges, lumière de retour détectée',
	'CK_VE_EXIF_FLASH_CASE_80'		=> 'Eteint, réduction yeux rouges',
	'CK_VE_EXIF_FLASH_CASE_88'		=> 'Auto, Did not fire, mode réduction yeux rouges',
	'CK_VE_EXIF_FLASH_CASE_89'		=> 'Flash déclenché, mode automatique, mode réduction yeux rouges',
	'CK_VE_EXIF_FLASH_CASE_93'		=> 'Flash déclenché, mode automatique, lumière de retour non détectée, mode réduction yeux rouges',
	'CK_VE_EXIF_FLASH_CASE_95'		=> 'Flash déclenché, mode automatique, lumière de retour détectée, mode réduction yeux rouges',

	'CK_VE_EXIF_FOCAL'				=> 'Distance focale',
	'CK_VE_EXIF_FOCAL_EXP'			=> '%s mm',// 'CK_VE_EXIF_FOCAL' unit

	'CK_VE_EXIF_ISO'				=> 'Sensibilité ISO',

	'CK_VE_EXIF_METERING_MODE'		=> 'Mode de mesure',
	'CK_VE_EXIF_METERING_MODE_0'	=> 'inconnue',
	'CK_VE_EXIF_METERING_MODE_1'	=> 'Evaluative',
	'CK_VE_EXIF_METERING_MODE_2'	=> 'Pondérée centrale',
	'CK_VE_EXIF_METERING_MODE_3'	=> 'Spot',
	'CK_VE_EXIF_METERING_MODE_4'	=> 'Multi-Spot',
	'CK_VE_EXIF_METERING_MODE_5'	=> 'Evaluative',
	'CK_VE_EXIF_METERING_MODE_6'	=> 'Sélective',
	'CK_VE_EXIF_METERING_MODE_255'	=> 'Autre',

	'CK_VE_EXIF_NOT_AVAILABLE'		=> 'non disponible',

	'CK_VE_EXIF_WHITEB'				=> 'Balance des blancs',
	'CK_VE_EXIF_WHITEB_AUTO'		=> 'Automatique',
	'CK_VE_EXIF_WHITEB_MANU'		=> 'Manuelle',

	'CK_VE_SHOW_EXIF'				=> 'voir/cacher',
	'CK_VE_CLICK_HERE'				=> 'Cliquer ici',
	'CK_VE_NAME_MAPSERVICE'			=> 'Google Maps'
));


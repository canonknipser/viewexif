<?php
/**
 *
 * This file is part of the phpBB Forum Software package.
 *
 * @copyright (c) phpBB Limited <https://www.phpbb.com>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 * For full copyright and license information, please see
 * the docs/CREDITS.txt file.
 *
 */

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'CK_VE_EXIF_CAPTION'			=> 'EXIF-Data',
	'CK_VE_EXIF_APERTURE'			=> 'F-Número',
	'CK_VE_EXIF_CAM_MODEL'			=> 'Modelo de cámara',
	'CK_VE_EXIF_CAM_MAKE'			=> 'Fabricante de la cámara',
	'CK_VE_EXIF_DATE'				=> 'Imagen tomada en',

	'CK_VE_EXIF_EXPOSURE'			=> 'Velocidad de obturación',
	'CK_VE_EXIF_EXPOSURE_EXP'		=> '%s Seg',// 'CK_VE_EXIF_EXPOSURE' unit
	'CK_VE_EXIF_EXPOSURE_BIAS'		=> 'Sesgo de exposición',
	'CK_VE_EXIF_EXPOSURE_BIAS_EXP'	=> '%s EV',// 'CK_VE_EXIF_EXPOSURE_BIAS' unit
	'CK_VE_EXIF_EXPOSURE_PROG'		=> 'Programa de exposición',
	'CK_VE_EXIF_EXPOSURE_PROG_0'	=> 'No definido',
	'CK_VE_EXIF_EXPOSURE_PROG_1'	=> 'Manual',
	'CK_VE_EXIF_EXPOSURE_PROG_2'	=> 'Programa normal',
	'CK_VE_EXIF_EXPOSURE_PROG_3'	=> 'Prioridad de apertura',
	'CK_VE_EXIF_EXPOSURE_PROG_4'	=> 'Prioridad de obturador',
	'CK_VE_EXIF_EXPOSURE_PROG_5'	=> 'Programa creativo (inclinado hacia la profundidad de campo)',
	'CK_VE_EXIF_EXPOSURE_PROG_6'	=> 'Programa de acción (orientado hacia una velocidad de obturación rápida)',
	'CK_VE_EXIF_EXPOSURE_PROG_7'	=> 'Modo de retrato (para las fotos del primer con el fondo desenfocado)',
	'CK_VE_EXIF_EXPOSURE_PROG_8'	=> 'Modo de paisaje (para fotos de paisaje con el fondo en foco)',

	'CK_VE_EXIF_FLASH'				=> 'Flash',

	'CK_VE_EXIF_FLASH_CASE_0'		=> 'No se disparó el flash',
	'CK_VE_EXIF_FLASH_CASE_1'		=> 'Flash disparado',
	'CK_VE_EXIF_FLASH_CASE_5'		=> 'Luz de retorno no detectada',
	'CK_VE_EXIF_FLASH_CASE_7'		=> 'Luz de retorno detectada',
	'CK_VE_EXIF_FLASH_CASE_8'		=> 'Encendido, no se disparó el flash',
	'CK_VE_EXIF_FLASH_CASE_9'		=> 'Flash disparado, modo de flash obligatorio',
	'CK_VE_EXIF_FLASH_CASE_13'		=> 'Flash disparado, modo de flash obligatorio, luz de retorno no detectada',
	'CK_VE_EXIF_FLASH_CASE_15'		=> 'Flash disparado, modo de flash obligatorio, luz de retorno detectada',
	'CK_VE_EXIF_FLASH_CASE_16'		=> 'No se disparó el flash, modo de flash obligatorio',
	'CK_VE_EXIF_FLASH_CASE_20'		=> 'Apagado, no se disparó el flash, luz de retorno no detectada',
	'CK_VE_EXIF_FLASH_CASE_24'		=> 'No se disparó el flash, modo automático',
	'CK_VE_EXIF_FLASH_CASE_25'		=> 'Flash disparado, modo automático',
	'CK_VE_EXIF_FLASH_CASE_29'		=> 'Flash disparado, modo automático, luz de retorno no detectada',
	'CK_VE_EXIF_FLASH_CASE_31'		=> 'Flash disparado, modo automático, luz de retorno detectada',
	'CK_VE_EXIF_FLASH_CASE_32'		=> 'Sin función de flash',
	'CK_VE_EXIF_FLASH_CASE_48'		=> 'Apagado, sin función de flash',
	'CK_VE_EXIF_FLASH_CASE_65'		=> 'Flash disparado, modo de reducción de ojos rojos',
	'CK_VE_EXIF_FLASH_CASE_69'		=> 'Flash disparado, modo de reducción de ojos rojos, luz de retorno no detectada',
	'CK_VE_EXIF_FLASH_CASE_71'		=> 'Flash disparado, modo de reducción de ojos rojos, luz de retorno detectada',
	'CK_VE_EXIF_FLASH_CASE_73'		=> 'Flash disparado, modo de flash obligatorio, modo de reducción de ojos rojos',
	'CK_VE_EXIF_FLASH_CASE_77'		=> 'Flash disparado, modo de flash obligatorio, modo de reducción de ojos rojos, luz de retorno no detectada',
	'CK_VE_EXIF_FLASH_CASE_79'		=> 'Flash disparado, modo de flash obligatorio, modo de reducción de ojos rojos, luz de retorno detectada',
	'CK_VE_EXIF_FLASH_CASE_80'		=> 'Apagado, reducción de ojos rojos',
	'CK_VE_EXIF_FLASH_CASE_88'		=> 'Automático, no se disparó, reducción de ojos rojos',
	'CK_VE_EXIF_FLASH_CASE_89'		=> 'Flash disparado, modo automático, modo de reducción de ojos rojos',
	'CK_VE_EXIF_FLASH_CASE_93'		=> 'Flash disparado, modo automático, luz de retorno no detectada, modo de reducción de ojos rojos',
	'CK_VE_EXIF_FLASH_CASE_95'		=> 'Flash disparado, modo automático, luz de retorno detectada, modo de reducción de ojos rojos',

	'CK_VE_EXIF_FOCAL'				=> 'Longitud del enfoque',
	'CK_VE_EXIF_FOCAL_EXP'			=> '%s mm',// 'CK_VE_EXIF_FOCAL' unit

	'CK_VE_EXIF_ISO'				=> 'Índice de velocidad ISO',

	'CK_VE_EXIF_METERING_MODE'		=> 'Modo de medición',
	'CK_VE_EXIF_METERING_MODE_0'	=> 'Desconocido',
	'CK_VE_EXIF_METERING_MODE_1'	=> 'Promedio',
	'CK_VE_EXIF_METERING_MODE_2'	=> 'Promedio ponderado en el centro',
	'CK_VE_EXIF_METERING_MODE_3'	=> 'Punto',
	'CK_VE_EXIF_METERING_MODE_4'	=> 'Multi-Punto',
	'CK_VE_EXIF_METERING_MODE_5'	=> 'Patrón',
	'CK_VE_EXIF_METERING_MODE_6'	=> 'Parcial',
	'CK_VE_EXIF_METERING_MODE_255'	=> 'Otro',

	'CK_VE_EXIF_NOT_AVAILABLE'		=> 'No disponible',

	'CK_VE_EXIF_WHITEB'				=> 'Balanza blanca',
	'CK_VE_EXIF_WHITEB_AUTO'		=> 'Auto',
	'CK_VE_EXIF_WHITEB_MANU'		=> 'Manual',

	'CK_VE_SHOW_EXIF'				=> 'Mostrar/Ocultar',
	'CK_VE_CLICK_HERE'				=> 'Clic aquí',
	'CK_VE_NAME_MAPSERVICE'			=> 'Google Maps'
));

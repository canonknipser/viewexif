<?php
/**
 *
 * This file is part of the phpBB Forum Software package.
 *
 * @copyright (c) phpBB Limited <https://www.phpbb.com>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 * For full copyright and license information, please see
 * the docs/CREDITS.txt file.
 *
 */

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'CK_VE_EXIF_CAPTION'				=> 'EXIF-Данные',
	'CK_VE_EXIF_APERTURE'			=> 'Диафрагма',
	'CK_VE_EXIF_CAM_MODEL'			=> 'Модель камеры',
	'CK_VE_EXIF_CAM_MAKE'			=> 'Производитель камеры',
	'CK_VE_EXIF_DATE'				=> 'Фотография была сделана',

	'CK_VE_EXIF_EXPOSURE'			=> 'Выдержка',
	'CK_VE_EXIF_EXPOSURE_EXP'		=> '%s Сек',// 'CK_VE_EXIF_EXPOSURE' unit
	'CK_VE_EXIF_EXPOSURE_BIAS'		=> 'Экспокоррекция',
	'CK_VE_EXIF_EXPOSURE_BIAS_EXP'	=> '%s EV',// 'CK_VE_EXIF_EXPOSURE_BIAS' unit
	'CK_VE_EXIF_EXPOSURE_PROG'		=> 'Определение выдержки',
	'CK_VE_EXIF_EXPOSURE_PROG_0'	=> 'Не определена',
	'CK_VE_EXIF_EXPOSURE_PROG_1'	=> 'Ручной',
	'CK_VE_EXIF_EXPOSURE_PROG_2'	=> 'Обычный режим',
	'CK_VE_EXIF_EXPOSURE_PROG_3'	=> 'Приоритет диафрагмы',
	'CK_VE_EXIF_EXPOSURE_PROG_4'	=> 'Приоритет выдержки',
	'CK_VE_EXIF_EXPOSURE_PROG_5'	=> 'Творческий режим (на основе нужной глубины резкости)',
	'CK_VE_EXIF_EXPOSURE_PROG_6'	=> 'Режим действий (смещена к быстрой скорости затвора)',
	'CK_VE_EXIF_EXPOSURE_PROG_7'	=> 'Портретный режим (для снимков на близком расстоянии, с фоном из фокуса)',
	'CK_VE_EXIF_EXPOSURE_PROG_8'	=> 'Ландшафтный режим (для пейзажных снимков, с фоном в фокусе)',

	'CK_VE_EXIF_FLASH'				=> 'Вспышка',

	'CK_VE_EXIF_FLASH_CASE_0'		=> 'Не сработала вспышка',
	'CK_VE_EXIF_FLASH_CASE_1'		=> 'Сработала вспышка',
	'CK_VE_EXIF_FLASH_CASE_5'		=> 'возвращение света не обнаружено',
	'CK_VE_EXIF_FLASH_CASE_7'		=> 'возвращение света обнаружено',
	'CK_VE_EXIF_FLASH_CASE_8'		=> 'Включена, не сработала вспышка',
	'CK_VE_EXIF_FLASH_CASE_9'		=> 'Сработала вспышка, в режиме заполняющей вспышки',
	'CK_VE_EXIF_FLASH_CASE_13'		=> 'Сработала вспышка, в режиме заполняющей вспышки, возвращение света не обнаружено',
	'CK_VE_EXIF_FLASH_CASE_15'		=> 'Сработала вспышка, в режиме заполняющей вспышки, возвращение света обнаружено',
	'CK_VE_EXIF_FLASH_CASE_16'		=> 'Не сработала вспышка, в режиме работы вспышки',
	'CK_VE_EXIF_FLASH_CASE_20'		=> 'Выключена, не сработала вспышка, возвращение света не обнаружено',
	'CK_VE_EXIF_FLASH_CASE_24'		=> 'Не сработала вспышка, в автоматическом режиме',
	'CK_VE_EXIF_FLASH_CASE_25'		=> 'Сработала вспышка, в автоматическом режиме',
	'CK_VE_EXIF_FLASH_CASE_29'		=> 'Сработала вспышка, в автоматическом режиме, возвращение света не обнаружено',
	'CK_VE_EXIF_FLASH_CASE_31'		=> 'Сработала вспышка, в автоматическом режиме, возвращение света обнаружено',
	'CK_VE_EXIF_FLASH_CASE_32'		=> 'Нет вспышки',
	'CK_VE_EXIF_FLASH_CASE_48'		=> 'Выключена, нет вспышки',
	'CK_VE_EXIF_FLASH_CASE_65'		=> 'Сработала вспышка, в режиме удаления эффекта красных глаз',
	'CK_VE_EXIF_FLASH_CASE_69'		=> 'Сработала вспышка, в режиме удаления эффекта красных глаз, возвращение света не обнаружено',
	'CK_VE_EXIF_FLASH_CASE_71'		=> 'Сработала вспышка, в режиме удаления эффекта красных глаз, возвращение света обнаружено',
	'CK_VE_EXIF_FLASH_CASE_73'		=> 'Сработала вспышка, в режиме заполняющей вспышки и режиме удаления эффекта красных глаз',
	'CK_VE_EXIF_FLASH_CASE_77'		=> 'Сработала вспышка, в режиме заполняющей вспышки и режиме удаления эффекта красных глаз, возвращение света не обнаружено',
	'CK_VE_EXIF_FLASH_CASE_79'		=> 'Сработала вспышка, в режиме заполняющей вспышки и режиме удаления эффекта красных глаз, возвращение света обнаружено',
	'CK_VE_EXIF_FLASH_CASE_80'		=> 'Выключен, режим удаления эффекта красных глаз',
	'CK_VE_EXIF_FLASH_CASE_88'		=> 'Не сработала вспышка, в автоматическом режиме и в режиме удаления эффекта красных глаз',
	'CK_VE_EXIF_FLASH_CASE_89'		=> 'Сработала вспышка, в автоматическом режиме и режиме удаления эффекта красных глаз',
	'CK_VE_EXIF_FLASH_CASE_93'		=> 'Сработала вспышка, в автоматическом режиме и режиме удаления эффекта красных глаз, возвращение света не обнаружено',
	'CK_VE_EXIF_FLASH_CASE_95'		=> 'Сработала вспышка, в автоматическом режиме и режиме удаления эффекта красных глаз, возвращение света обнаружено',

	'CK_VE_EXIF_FOCAL'				=> 'Фокусное расстояние объектива',
	'CK_VE_EXIF_FOCAL_EXP'			=> '%s мм',// 'CK_VE_EXIF_FOCAL' unit

	'CK_VE_EXIF_ISO'				=> 'Чувствительность ISO',

	'CK_VE_EXIF_METERING_MODE'		=> 'Режим замера экспозиции',
	'CK_VE_EXIF_METERING_MODE_0'	=> 'Неизвестный',
	'CK_VE_EXIF_METERING_MODE_1'	=> 'Усредненный',
	'CK_VE_EXIF_METERING_MODE_2'	=> 'Центрально-взвешенный усредненный',
	'CK_VE_EXIF_METERING_MODE_3'	=> 'Точечный',
	'CK_VE_EXIF_METERING_MODE_4'	=> 'Многоточечный',
	'CK_VE_EXIF_METERING_MODE_5'	=> 'По шаблону',
	'CK_VE_EXIF_METERING_MODE_6'	=> 'Частичного измерения',
	'CK_VE_EXIF_METERING_MODE_255'	=> 'Другой',

	'CK_VE_EXIF_NOT_AVAILABLE'		=> 'не определен',

	'CK_VE_EXIF_WHITEB'				=> 'Баланс белого',
	'CK_VE_EXIF_WHITEB_AUTO'		=> 'Авто',
	'CK_VE_EXIF_WHITEB_MANU'		=> 'Пользовательский',

	'CK_VE_SHOW_EXIF'				=> 'показать/спрятать',
	'CK_VE_CLICK_HERE'				=> 'нажмите здесь',
	'CK_VE_NAME_MAPSERVICE'			=> 'Google Карты'
));

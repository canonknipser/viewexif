<?php
/**
 *
 * This file is part of the viewexif extension for phpBB.
 * @package View Exif
 * @copyright (c) 2017, canonknipser
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'UCP_CK_VE'						=>	'Ajustes',
	'UCP_CK_VE_TITLE'				=>	'Mostrar datos exif',
	'UCP_CK_VE_ACTIVE'				=>	'¿Activar EXIF?',
	'UCP_CK_VE_ACTIVE_EXPLAIN'		=>	'Mostrar datos EXIF de las imágenes adjuntas si es posible.',
	'UCP_CK_VE_MAPSERVICE'			=>	'Servicio de mapa',
	'UCP_CK_VE_MAPSERVICE_EXPLAIN'	=>	'Seleccione el servicio de mapas que se debe usar para mostrar las coordenadas GPS incrustado en una imagen.',
	'UCP_CK_VE_SAVED'				=>	'¡Los ajustes han sido guardados correctamente!',
	'UCP_CK_VE_GOOGLEMAPS'			=>	'Mapas de Google',
	'UCP_CK_VE_OSM'					=>	'Abrir mapas de calles',
));

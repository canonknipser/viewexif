<?php
/**
 *
 * This file is part of the viewexif extension for phpBB.
 * @package View Exif
 * @copyright (c) 2017, canonknipser
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'ACP_CK_VE'								=> 'Ajustes para “Mostrar datos exif”',
	'ACP_CK_VE_TITLE'						=> 'Mostrar datos exif',
	'ACP_CK_VE_ACTIVE'						=> '¿Activar EXIF?',
	'ACP_CK_VE_ACTIVE_EXPLAIN'				=> 'Mostrar datos EXIF para las imágenes adjuntas si es posible. El usuario puede desactivar los datos EXIF en su PCU.',
	'ACP_CK_VE_USE_MAPS'					=> 'Usar servicio de mapa',
	'ACP_CK_VE_USE_MAPS_EXPLAIN'			=> '¿Permitir a los usuarios navegar por mapas con la posición GPS de una imagen?<br/>Nota: Para ver la posición de la imagen en un mapa, la visualización de los datos del GPS debe estar habilitado.',
	'ACP_CK_VE_SAVED'						=> '¡Los ajustes han sido guardados correctamente!',
	'ACP_CK_VE_VERSION'						=> 'Versión actual de viewexif',
	'ACP_CK_VE_FORUM_ALLOW'					=> '¿Mostrar datos EXIF?',
	'ACP_CK_VE_FORUM_ALLOW_EXPLAIN'			=> '¿Mostrar datos EXIF en este foro? Si esta deshabilitado, no se muestra EXIF, incluso si está presente en una imagen adjunta en un mensaje de este foro',
	'ACP_CK_VE_INDIVIDUAL'					=> 'Habilitar / Deshabilitar la visualización de entradas EXIF individuales',
	'ACP_CK_VE_ALLOW_DATE'					=> 'Fecha',
	'ACP_CK_VE_ALLOW_DATE_EXPLAIN'			=> 'Mostrar fecha',
	'ACP_CK_VE_ALLOW_FOCAL_LENGTH'			=> 'Longitud focal',
	'ACP_CK_VE_ALLOW_FOCAL_LENGTH_EXPLAIN'	=> 'Mostrar longitud focal',
	'ACP_CK_VE_ALLOW_EXPOSURE_TIME'			=> 'Tiempo de exposición',
	'ACP_CK_VE_ALLOW_EXPOSURE_TIME_EXPLAIN'	=> 'Mostrar tiempo de exposición',
	'ACP_CK_VE_ALLOW_F_NUMBER'				=> 'F-Número',
	'ACP_CK_VE_ALLOW_F_NUMBER_EXPLAIN'		=> 'Mostrar F-Número',
	'ACP_CK_VE_ALLOW_ISO'					=> 'ISO',
	'ACP_CK_VE_ALLOW_ISO_EXPLAIN'			=> 'Mostrar ISO',
	'ACP_CK_VE_ALLOW_WB'					=> 'Balance de blanco',
	'ACP_CK_VE_ALLOW_WB_EXPLAIN'			=> 'Mostrar balence de blanco',
	'ACP_CK_VE_ALLOW_FLASH'					=> 'Modo Flash',
	'ACP_CK_VE_ALLOW_FLASH_EXPLAIN'			=> 'Mostrar modo Flash',
	'ACP_CK_VE_ALLOW_MAKE'					=> 'Hacer',
	'ACP_CK_VE_ALLOW_MAKE_EXPLAIN'			=> 'Mostrar hacer',
	'ACP_CK_VE_ALLOW_MODEL'					=> 'Modelo',
	'ACP_CK_VE_ALLOW_MODEL_EXPLAIN'			=> 'Mostrar modelo',
	'ACP_CK_VE_ALLOW_EXPOSURE_PROG'			=> 'Programa de exposición',
	'ACP_CK_VE_ALLOW_EXPOSURE_PROG_EXPLAIN'	=> 'Mostrar programa de exposición',
	'ACP_CK_VE_ALLOW_EXPOSURE_BIAS'			=> 'Exposición parcial',
	'ACP_CK_VE_ALLOW_EXPOSURE_BIAS_EXPLAIN'	=> 'Mostrar exposición parcial',
	'ACP_CK_VE_ALLOW_METERING'				=> 'Modo de medición',
	'ACP_CK_VE_ALLOW_METERING_EXPLAIN'		=> 'Mostrar modo de medición',
	'ACP_CK_VE_ALLOW_GPS'					=> 'Datos GPS',
	'ACP_CK_VE_ALLOW_GPS_EXPLAIN'			=> 'Mostrar datos GPS',
));

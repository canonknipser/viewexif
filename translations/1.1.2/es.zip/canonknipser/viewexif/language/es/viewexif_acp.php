<?php
/**
 *
 * This file is part of the viewexif extension for phpBB.
 * @package View Exif
 * @copyright (c) 2017 Frank Jakobs (canonknipser)
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'CK_VE_REQUIRE_EXIF'				=> 'Esta extensión requiere que la biblioteca exif de PHP instalada. Por favor, actualice su instalación de PHP',
	'CK_VE_REQUIRE_316'					=> 'Esta extensión requiere al menos la versión 3.1.6 de phpBB',
));
